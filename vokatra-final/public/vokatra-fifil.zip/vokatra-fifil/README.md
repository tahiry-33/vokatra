# Vokatra — FIFIL Fileovana Paris (v2)

Boutique solidaire de la paroisse FIFIL Fileovana Paris, édition mai 2026.

## Design

- Direction : bakery artisanale, chaleureuse et moderne
- Palette : crème + vert forêt + or, avec du cardinal uniquement sur le CTA principal et le prix
- Typographie : **Fraunces** (serif caractérielle, titres) + **DM Sans** (corps, 17px de base)
- Mobile-first, tap targets 48px minimum, bottom navigation, cart bottom sheet
- Accessibilité : focus visible, prefers-reduced-motion respecté, labels associés

## Fonctionnalités

- **Boutique** : 2 produits (Godrogodro + Cake) avec illustrations SVG inline, gestion stock et quantités
- **Panier** : bottom sheet avec ajustement des quantités, total en direct
- **Checkout** : formulaire d'informations (prénom, nom, email, téléphone, adresse, date de livraison)
  - Date de livraison : samedi 9 mai 2026 ou dimanche 10 mai 2026 (codées en dur)
  - Mode de paiement : espèces à la livraison OU carte bancaire (Stripe)
- **Page de confirmation** : récapitulatif complet, référence commande
- **Faire un don** : 5 montants prédéfinis + montant libre, paiement carte
- **Admin** : URL `?admin=fifil2026`, 3 onglets (Commandes / Dons / Produits), statistiques et détails

## Mode démo

Tant que `SUPA_URL` contient `REMPLACE_MOI`, le site tourne en **mode démo** : les 2 produits s'affichent avec prix indicatifs (5 € / 7 €), le checkout fonctionne mais ne persiste rien, la page de confirmation s'affiche quand même.

## Passage en production

1. Créer/choisir le projet Supabase FIFIL Fileovana Paris
2. Créer les tables `products`, `orders`, `order_items`, `delivery_dates` (voir README v1)
3. Déployer l'edge function `rapid-function` (copier depuis le projet Bordeaux)
4. Remplacer ligne ~ de `index.html` :
   ```js
   const SUPA_URL = 'https://<ref>.supabase.co';
   const SUPA_KEY = '<anon-key>';
   const ADMIN_SECRET = 'choisir-un-code';
   ```
5. Drag-and-drop du dossier `public/` sur Netlify

## Palette

- `--forest: #2D4A3E` (accent principal / boutons)
- `--cardinal: #8B1528` (CTA principal + prix)
- `--gold: #C9A020` (touches décoratives)
- `--bg: #FAF6EF` (fond crème)
- `--surface: #FFFFFF` (cartes)
